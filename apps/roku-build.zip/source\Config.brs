function Flyhigh_GetConfig() as Object
    return {
        apiBaseUrl: "http://172.20.10.2:4000"
        webActivateBaseUrl: "http://172.20.10.2:3002"
        appName: "roku-dev"
    }
end function
